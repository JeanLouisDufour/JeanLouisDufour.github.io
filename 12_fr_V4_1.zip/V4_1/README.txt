Les 3 fichiers image ".png" doivent �tre � c�t� du .rtf
(ils ne sont pas inclus dedans, juste appel�s)
 